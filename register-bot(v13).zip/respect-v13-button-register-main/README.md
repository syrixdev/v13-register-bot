# respect-v13-button-register

Çözebileceğin çok kolay hatalar mevcut.
Hatasız ve üstüne oturup benim diyebileceğin projeler istiyorsan **star** at.

Çözemediğin bir sorun olursa discord; respect 🎄#0001 ID: 919663047923101736

Ha hala çözemion discord.gg/serendia gel ve etiketle 
